# Governance contract

This directory owns decisions, policy, registries, backlog state and human review records.

- Decisions record explicit owner direction and their effective date.
- Registries describe approved roles and lifecycle state; they do not infer assignments.
- Reports are evidence and review records unless an owner decision explicitly ratifies them.
- The backlog is a flat title list. Items receive detail only when the owner promotes them.
- Human-facing reports require a dark visual design and purposeful diagrams.

