# Knowledge and authority routing

## Precedence

1. Current explicit owner decisions and this constitution
2. Accepted specifications, policies, registries and contracts
3. Current measured host/runtime evidence
4. Official upstream source and documentation pinned by the local library
5. HX-distilled library knowledge
6. Historical reports, prompts, session notes and conversation records

Agents must surface a conflict and use the higher authority. Detail does not outrank authority.

## Retrieval route

| Question | Read first |
|---|---|
| What are we building now? | Active `specs/<mission>/spec.md` |
| What may happen next? | Active `plan.md` and `tasks.md` |
| What is HXS-1 actually? | `servers/hxs-1/discovery.md` and current evidence |
| How should Ubuntu/storage be handled? | `library/technologies/ubuntu-server/` and Owen |
| How should NVIDIA devices be identified? | `library/technologies/nvidia-cuda/` and Owen |
| How does Ollama behave? | `library/technologies/ollama/` and Craig |
| Which Qwen artifact/settings are correct? | `library/technologies/qwen/` and Quincy |
| How is Claude Code configured? | `library/technologies/claude-code/` and ADR-0004 |
| Which Kimi model/profile is approved? | `library/technologies/kimi/` and provider registry |
| How may DeepSeek drive HX work? | `library/technologies/deepseek/` and provider registry |
| Has MVP-1 passed? | `specs/.../acceptance.md`, evidence and Tessa |

## Knowledge Base Review gate

Before mutation, each specialist must:

1. identify the exact technology library it requires;
2. read its `library.yaml` and `source-lock.yaml`;
3. run `bash platform/hxs-cp/bin/hx-library.sh verify <technology>` when supported;
4. record the source revision reviewed in the handoff;
5. stop if a required source is absent, stale or mismatched.

## Library boundary

The library may explain implementation behavior. It may not assign server roles, approve risk, change scope, accept a runtime or overrule current evidence.
