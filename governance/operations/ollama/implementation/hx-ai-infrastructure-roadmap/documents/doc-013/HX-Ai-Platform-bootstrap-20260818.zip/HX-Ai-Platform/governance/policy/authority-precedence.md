# Authority precedence

1. Current explicit owner decision
2. Constitution
3. Accepted specifications and decisions
4. Canonical host and agent registries
5. Current measured evidence
6. Locked official upstream source/documentation
7. Distilled local library knowledge
8. Historical reports, prompts and session records

When two items at the same level conflict, use the newest item whose scope directly covers the question and record the conflict.

