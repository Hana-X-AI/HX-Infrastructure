# HXS-1

| Record | Meaning |
|---|---|
| `discovery.md` | migrated as-found and post-driver evidence |
| `driver-results.md` | retained raw driver validation session |
| `target.md` | approved MVP-1 intended state |
| `evidence/` | results generated when MVP-1 executes |

```mermaid
stateDiagram-v2
    [*] --> Discovered
    Discovered --> DriverValidated
    DriverValidated --> StorageReady
    StorageReady --> OllamaReady
    OllamaReady --> ModelReady
    ModelReady --> MessageAnswered
    MessageAnswered --> Accepted
```

