# Ubuntu Server knowledge

Scope for MVP-1: validate the already-installed Ubuntu 24.04.4 host, resolve the spare NVMe by serial, prepare `/srv/hx-ai`, and hand a verified platform state to Craig.

No operating-system upgrade or unrelated package work belongs to MVP-1.

