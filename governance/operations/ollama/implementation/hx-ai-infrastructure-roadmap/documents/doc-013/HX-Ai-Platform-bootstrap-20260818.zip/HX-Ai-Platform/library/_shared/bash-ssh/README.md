# Bash/SSH control pattern

MVP-1 commands originate on `hxs-cp`, use SSH user `hxsa`, target HXS-1 directly at `192.168.50.200`, copy scripts to `/tmp` when required, and use passwordless `sudo` only inside the approved runbook.

Every remote mutation must be preceded by an identity check and followed by verification. Host-controlled values must not determine local evidence filenames.

