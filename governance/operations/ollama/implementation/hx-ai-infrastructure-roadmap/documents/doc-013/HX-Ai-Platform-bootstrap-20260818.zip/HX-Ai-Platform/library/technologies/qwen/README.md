# Qwen model knowledge

MVP-1 is locked to the non-drafting `qwen3.8:27b-q4_K_M` manifest. The bare `qwen3.8:27b` tag is a distinct manifest that adds `draft_num_predict=4` and is not interchangeable.

Quincy verifies the manifest before the smoke request and uses explicit request settings.

