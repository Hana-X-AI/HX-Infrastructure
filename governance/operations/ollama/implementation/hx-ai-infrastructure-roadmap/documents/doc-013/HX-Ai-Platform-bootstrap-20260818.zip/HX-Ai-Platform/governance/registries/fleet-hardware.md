# HX fleet hardware migration baseline

**Truth state:** MIGRATED HARDWARE BASELINE  
**Source:** `HX-Infrastructure-main (4).zip`, SHA-256 `5dd124e1b5a391fc102ab553fb9bc05eece57e73190283dbfe5e060736d26779`  
**Note:** Hardware is preserved here independently from workload reassignment.

| Server | IP | CPU | RAM | GPU / VRAM | Storage summary |
|---|---:|---|---:|---|---|
| hxs-1 | 192.168.50.200 | Core Ultra 9 285K, 24c/24t | 128 GB | 2× RTX 4070 Ti SUPER, 32,752 MiB | 3.6 TB root NVMe; 3.6 TB spare NVMe; 7.3 TB SATA |
| hxs-2 | 192.168.50.201 | Core i7-5960X, 8c/16t | 66 GB | 2× RTX 5060 Ti, 32,622 MiB | 3.6 TB root NVMe; 2× 596 GB SATA |
| hxs-3 | 192.168.50.202 | Core i7-5960X, 8c/16t | 66 GB | 2× RTX 5060 Ti, 32,622 MiB | 3.6 TB root NVMe; 1.8 TB SATA SSD |
| hxs-4 | 192.168.50.203 | Core i7-14700F, 20c/28t | 32 GB | RTX 5060 Ti + RTX 5060, 24,462 MiB | 931 GB root NVMe; 476 GB spare NVMe |
| hxs-5 | 192.168.50.204 | Core i5-7500, 4c/4t | 32 GB | none | 238 GB NVMe |
| hxs-6 | 192.168.50.205 | Core i5-8500T, 6c/6t | 15.9 GB | none | 238 GB NVMe |
| hxs-7 | 192.168.50.206 | Core i5-8500T, 6c/6t | 15.9 GB | none | 238 GB NVMe |
| hxs-8 | 192.168.50.207 | Core i5-9400T, 6c/6t | 16 GB | none | 476 GB NVMe |
| hxs-9 | 192.168.50.208 | Core i5-7500, 4c/4t | 32 GB | none | 238 GB NVMe |
| hxs-10 | 192.168.50.209 | Core i5-7500, 4c/4t | 32 GB | none | 238 GB NVMe |
| hxs-11 | 192.168.50.210 | Core i5-7500, 4c/4t | 32 GB | none | 238 GB NVMe |
| hxs-12 | 192.168.50.211 | Core i5-7500, 4c/4t | 32 GB | none | 238 GB NVMe |
| hxs-13 | 192.168.50.212 | Core i5-6500, 4c/4t | 32 GB | none | 238 GB SATA SSD |
| hxs-14 | 192.168.50.213 | Core i5-7500, 4c/4t | 32 GB | none | 238 GB NVMe |
| hxs-15 | 192.168.50.214 | Core i5-7500, 4c/4t | 32 GB | none | 238 GB NVMe |

Full per-host discovery migration remains a later repository task. HXS-1 is migrated now because it is the active mission.

