# Human reports

Human-facing reports live here. Every report must include at least one diagram or other visual that makes architecture, sequence, state, or evidence easier to understand.

