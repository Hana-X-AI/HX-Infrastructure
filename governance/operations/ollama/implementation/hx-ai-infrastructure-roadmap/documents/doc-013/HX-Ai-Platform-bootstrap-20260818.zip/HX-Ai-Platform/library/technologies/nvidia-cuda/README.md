# NVIDIA/CUDA host knowledge

MVP-1 consumes the validated driver already installed on HXS-1. Owen captures both GPU UUIDs and the PCIe link evidence. The driver, CUDA toolkit and firmware are not changed.

