# DeepSeek knowledge

DeepSeek V4 is the owner-approved independent-validation and bounded-volume provider capability, pending configuration acceptance. Tessa is assigned to DeepSeek V4 Pro by default. DeepSeek V4 Flash is preferred for explicitly approved bounded-volume workloads. Both must run in a process isolated from the Kimi profile.

## Selected baseline

| Concern | Value |
|---|---|
| Anthropic-compatible endpoint | `https://api.deepseek.com/anthropic` |
| Main model | `deepseek-v4-pro[1m]` |
| Background/subagent model | `deepseek-v4-flash` |
| Context | 1M tokens |
| Auto-compact trigger | `786432` |
| Reasoning effort | `max` |

DeepSeek documents Anthropic API compatibility, Claude Code integration, tool calls, a 1M context window, and Web Search support. Web Search incurs additional model calls and is not tested without owner approval.

DeepSeek V4 Pro receives retained evidence produced by the Kimi implementation lane. Provider diversity does not waive Tessa's procedural independence: she validates, records `PASS`, `FAIL` or `BLOCKED`, and never repairs the work under review.
