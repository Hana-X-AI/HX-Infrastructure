# Workload assignments

**Truth state:** CURRENT OWNER ASSIGNMENT

| Host | Role | Active workload | Lifecycle |
|---|---|---|---|
| hxs-1 | Deep reasoning and synthesis | Qwen3.8 27B through Ollama | MVP-1 approved; not yet as-built |

Other fleet assignments from the historical repository are not silently promoted into this new authority. They will be reconciled when their missions enter the critical path.

