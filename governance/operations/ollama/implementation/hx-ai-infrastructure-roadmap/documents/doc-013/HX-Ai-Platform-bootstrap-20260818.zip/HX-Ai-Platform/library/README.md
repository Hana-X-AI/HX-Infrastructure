# Local agent knowledge library

This directory is the local, source-provenanced knowledge plane for active HX agents.

```mermaid
flowchart LR
    S["Locked upstream source"] --> I["Indexes and distilled knowledge"]
    I --> A["Specialist agent"]
    G["Governance authority"] --> A
    A --> E["Evidence"]
    E --> G
```

Library content is advisory. It cannot override governance, accepted specifications or current measured evidence.

Technology directories are created only for active work. A directory's presence means knowledge is available; it does not grant architecture authority.

