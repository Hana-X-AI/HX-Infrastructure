# Claude Code provider routing registry

**Truth state:** OWNER-APPROVED TARGET; NOT YET CONFIGURED
**Updated:** 2026-08-18

```mermaid
flowchart TD
    M["Meta-Agent · Kimi K3"] --> A["Owen → Craig → Quincy · Kimi K3"]
    A --> E["Retained implementation evidence"]
    E --> T["Tessa · DeepSeek V4 Pro"]
    T --> G["Owner / governance decision"]
    F["DeepSeek V4 Flash"] --> B["Approved bounded-volume work"]
```

| Routing concern | Current decision |
|---|---|
| Default Claude Code execution provider | **Kimi K3: adopt as default, pending configuration acceptance** |
| Default Kimi model | `kimi-k3[1m]` |
| Default independent-validation provider | **DeepSeek V4 Pro for Tessa, pending configuration acceptance** |
| Preferred bounded-volume provider | **DeepSeek V4 Flash, only when the workload is explicitly approved** |
| DeepSeek main model | `deepseek-v4-pro[1m]` |
| DeepSeek background/subagent model | `deepseek-v4-flash` |
| Provider selection | separate process profile |
| Mixed providers in native Claude subagents | prohibited |
| Per-agent cross-provider routing | future traffic-plane acceptance |
| Credential storage | outside Git; owner-readable `0600` files |
| Runtime status | not configured |

## Named-agent assignments

| Agent | Default provider and model | Process boundary | Authority |
|---|---|---|---|
| Meta-Agent | Kimi · `kimi-k3[1m]` | default Kimi process | stage routing only |
| Owen | Kimi · `kimi-k3[1m]` | Kimi process | host and storage implementation |
| Craig | Kimi · `kimi-k3[1m]` | Kimi process | Ollama implementation |
| Quincy | Kimi · `kimi-k3[1m]` | Kimi process | model implementation |
| Tessa | DeepSeek · `deepseek-v4-pro[1m]` | new, isolated DeepSeek process | independent PASS/FAIL |

`deepseek-v4-flash` is not a standing named-agent assignment. It is the preferred model for an owner- or Meta-Agent-approved bounded-volume workload inside a DeepSeek process. Cross-provider handoff occurs through retained evidence until traffic-plane routing passes a separate acceptance decision.
