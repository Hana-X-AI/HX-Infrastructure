# Human artifact standard

Human-facing HX-Ai-Platform material must:

- default to a dark/night visual theme;
- include at least one purposeful diagram when topology, ownership, flow or state is material;
- lead with outcome and truth state;
- state the completed object, its evidence-backed state and the next gate;
- distinguish as-built, proposed, accepted, backlog and historical information;
- reserve “deployed” for a target environment with retained execution evidence;
- avoid colloquial or ambiguous status language such as “stood up,” “good to go” or “locally deployed”;
- use lowercase filenames containing assistant/model, date and time;
- keep dense implementation detail in linked agent/source artifacts.

Diagrams clarify relationships; they may not replace exact commands, tables or evidence.
