# Claude agent catalogue contract

Files in `.claude/agents/` define executable specialist boundaries.

- Keep the active roster small.
- Do not create an agent merely because a technology exists.
- Every agent must state purpose, ownership, exclusions, required knowledge and evidence handoff.
- Every agent must complete the Knowledge Base Review before mutation.
- Tessa remains independent from implementation agents.
- Agent definitions may not contain host credentials or remembered environment secrets.

