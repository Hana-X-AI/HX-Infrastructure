# HXS-1 target state — MVP-1

**Truth state:** APPROVED TARGET; NOT YET AS-BUILT

- spare NVMe serial `250816800905` mounted at `/srv/hx-ai` by filesystem UUID;
- existing NVIDIA driver `580.173.02` unchanged;
- both GPU UUIDs recorded and supplied to Ollama;
- Ollama `0.32.14` listening only on `127.0.0.1:11434`;
- model store at `/srv/hx-ai/ollama/models`;
- `qwen3.8:27b-q4_K_M` manifest `25b843619e94` present;
- context `8192`, flash attention enabled and thinking effort `medium`;
- a loopback API prompt returns a coherent answer;
- independent Tessa validation recorded.

