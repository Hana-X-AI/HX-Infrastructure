# HXS-1 evidence

Create one timestamped directory per execution attempt. Retain exact command output and a concise accepted summary. Raw transient logs may be ignored until reviewed.

Expected MVP-1 evidence:

- `owen-host-preflight.txt`
- `owen-storage-result.txt`
- `craig-ollama-version.txt`
- `craig-service-state.txt`
- `quincy-model-manifest.txt`
- `quincy-smoke-response.json`
- `tessa-validation.md`

