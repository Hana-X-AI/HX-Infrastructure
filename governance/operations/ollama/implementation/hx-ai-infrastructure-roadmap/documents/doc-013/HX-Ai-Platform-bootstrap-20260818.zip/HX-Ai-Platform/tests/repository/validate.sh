#!/usr/bin/env bash
set -euo pipefail

repo_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
cd "$repo_root"

required=(
  AGENTS.md
  CLAUDE.md
  .specify/memory/constitution.md
  knowledge/instructions.md
  governance/registries/agent-catalog.yaml
  library/catalog.yaml
  specs/001-hxs1-qwen38-ollama-mvp1/spec.md
  specs/001-hxs1-qwen38-ollama-mvp1/runbook.md
  specs/001-hxs1-qwen38-ollama-mvp1/acceptance.md
  platform/hxs-1/ollama/requests/mvp1-chat.json
  governance/reports/codex_20260818_1115_hx-ai-platform-bootstrap-and-directive-recon.html
  governance/reports/chatgpt_20260818_1135_claude-code-provider-architecture-recon.html
  governance/decisions/0004-claude-code-provider-isolation.md
  governance/registries/claude-code-provider-routing.md
  governance/operations/claude-code/implementation-prompt.md
)

for path in "${required[@]}"; do
  [[ -f "$path" ]] || { echo "missing: $path" >&2; exit 10; }
done

agent_count=$(find .claude/agents -maxdepth 1 -type f -name '*.md' | wc -l)
[[ "$agent_count" -eq 5 ]] || { echo "expected 5 active agent files, found $agent_count" >&2; exit 11; }

for tech in ubuntu-server nvidia-cuda ollama qwen claude-code kimi deepseek; do
  [[ -f "library/technologies/$tech/library.yaml" ]] || { echo "missing $tech library manifest" >&2; exit 12; }
  [[ -f "library/technologies/$tech/source-lock.yaml" ]] || { echo "missing $tech source lock" >&2; exit 13; }
done

while IFS= read -r script; do
  bash -n "$script"
done < <(find platform tests -type f -name '*.sh' | sort)

grep -q 'qwen3.8:27b-q4_K_M' platform/hxs-1/ollama/requests/mvp1-chat.json
grep -q '"think": "medium"' platform/hxs-1/ollama/requests/mvp1-chat.json
grep -q '"num_ctx": 8192' platform/hxs-1/ollama/requests/mvp1-chat.json
grep -q '391' specs/001-hxs1-qwen38-ollama-mvp1/acceptance.md
grep -q '25b843619e94' governance/decisions/0003-hxs1-mvp1-runtime-locks.md

report=governance/reports/codex_20260818_1115_hx-ai-platform-bootstrap-and-directive-recon.html
grep -Eq 'role="img"|<svg|<img' "$report" || { echo "human report has no purposeful visual" >&2; exit 14; }
grep -q 'Repository baseline complete. Controlled deployment is the next gate.' "$report" || { echo "human report lacks the approved executive status" >&2; exit 15; }
if grep -RqiE 'stood up|good to go|locally deployed' README.md governance/reports; then
  echo "ambiguous executive status language detected" >&2
  exit 16
fi

provider_report=governance/reports/chatgpt_20260818_1135_claude-code-provider-architecture-recon.html
grep -Eq 'role="img"|<svg|<img' "$provider_report" || { echo "provider report has no purposeful visual" >&2; exit 17; }
grep -q '<title>Hana-X Claude Code Provider Architecture' "$provider_report" || { echo "provider report lacks the approved executive title" >&2; exit 18; }
grep -q 'One provider boundary per Claude Code process' "$provider_report" || { echo "provider isolation decision missing" >&2; exit 19; }
grep -q "Tessa's default independent-validation provider" governance/decisions/0004-claude-code-provider-isolation.md || { echo "Tessa provider decision missing" >&2; exit 21; }
grep -q 'default_model: deepseek-v4-pro\[1m\]' governance/registries/agent-catalog.yaml || { echo "Tessa DeepSeek model assignment missing" >&2; exit 22; }
grep -q 'DeepSeek V4 Flash.*bounded-volume' governance/registries/claude-code-provider-routing.md || { echo "DeepSeek Flash workload policy missing" >&2; exit 23; }

prompt=governance/operations/claude-code/implementation-prompt.md
grep -q 'CLAUDE_CODE_AUTO_COMPACT_WINDOW=1000000' "$prompt"
grep -q 'CLAUDE_CODE_AUTO_COMPACT_WINDOW=786432' "$prompt"
grep -q 'Never ask the owner to paste either API key into chat' "$prompt"
grep -q 'acceptance conditions 1–12' "$prompt"

if find . -type f -not -path './.git/*' -not -path './library/technologies/ollama/sources/*' -print0 | xargs -0 grep -IlE '(sk-[A-Za-z0-9_-]{20,}|ANTHROPIC_AUTH_TOKEN=[A-Za-z0-9_-]{20,})' | grep -q .; then
  echo "possible API credential detected" >&2
  exit 20
fi

echo "HX-Ai-Platform repository validation: PASS"
