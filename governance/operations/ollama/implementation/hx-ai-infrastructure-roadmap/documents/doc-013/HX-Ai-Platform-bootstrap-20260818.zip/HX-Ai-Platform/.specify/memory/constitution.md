# HX-Ai-Platform Constitution

**Version:** 1.0.0  
**Ratified:** 2026-08-18  
**Truth state:** OWNER-DIRECTED BASELINE

## Article I — Owner intent

Explicit current owner direction is the highest project authority. When owner directives conflict, the latest specific direction governs. The conflict must be recorded; it must not be silently blended.

## Article II — Critical-path discipline

Every task is classified by one test:

> Does the active MVP's definition of done fail without this task?

If yes, the task belongs to the active MVP. If no, its title goes to the backlog. Convenience, convention, novelty and generic best practice do not create a third category.

## Article III — MVP ladder

Work advances through the smallest observable working states. Only the active MVP is detailed. Later MVPs contain a title and one-line outcome until the owner promotes one.

## Article IV — sdd-core control flow

Owner intent is translated through the file-driven specification and the Meta-Agent. Specialists act only inside a bounded stage and may not redefine product intent, stage order or acceptance.

## Article V — Capability ownership

One agent owns one bounded capability. Cross-capability work uses explicit handoffs. The implementing agent cannot certify its own work; independent validation is required for completion.

## Article VI — Authority and knowledge

Governance and accepted specifications are authoritative. The local technology library is advisory evidence. Live measurements govern current host/runtime facts. Historical material is evidence only.

## Article VII — Evidence before claims

Installation is not acceptance. A stage completes only when its defined observable output exists and the required evidence is retained. Missing, stale or mismatched source knowledge stops the agent before mutation.

## Article VIII — Human communication

Human-facing HX artifacts use a dark visual design and include diagrams that clarify topology, flow, state or ownership. Agent/source records remain concise Markdown.

## Amendment rule

Only explicit owner direction may amend this constitution. Changes require a recorded decision and a version increment.

