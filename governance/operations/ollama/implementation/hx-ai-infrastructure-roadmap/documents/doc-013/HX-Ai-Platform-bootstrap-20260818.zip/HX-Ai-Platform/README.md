# HX-Ai-Platform

HX-Ai-Platform is the specification-driven control repository for the Hana-X local AI fleet.

> **Executive status:** Repository baseline complete and locally validated. Ready for remote publication and controlled execution from `hxs-cp`. HXS-1 has not been modified.

The current mission is deliberately narrow: bring `qwen3.8:27b-q4_K_M` online through Ollama on HXS-1 and prove one coherent response from the loopback API.

## Operating flow

```mermaid
flowchart TD
    O["Owner intent"] --> S["sdd-core / Meta-Agent"]
    S --> W["Owen · host readiness"]
    W --> C["Craig · Ollama runtime"]
    C --> Q["Quincy · Qwen artifact"]
    Q --> T["Tessa · independent validation"]
    T --> G["Governance decision + retained evidence"]
```

## Repository topology

```mermaid
flowchart LR
    A["Governance"] --> K["knowledge/instructions.md"]
    K --> M["Meta-Agent"]
    L["Local technology library"] --> M
    M --> P["Platform automation"]
    P --> E["Runtime evidence"]
    E --> A
```

## Claude Code provider architecture

**Target state; not yet configured:** Kimi K3 is the default execution provider. Tessa performs independent validation from an isolated DeepSeek V4 Pro process. DeepSeek V4 Flash is preferred for explicitly approved bounded-volume workloads.

```mermaid
flowchart TD
    O["Owner intent"] --> K["Kimi K3 · Meta-Agent"]
    K --> E["Owen → Craig → Quincy"]
    E --> H["Retained evidence handoff"]
    H --> T["DeepSeek V4 Pro · Tessa"]
    T --> G["Governance decision"]
    F["DeepSeek V4 Flash"] --> B["Approved bounded-volume work"]
```

See `governance/decisions/0004-claude-code-provider-isolation.md` and the execution-ready prompt under `governance/operations/claude-code/`.

## Directory contract

| Path | Responsibility |
|---|---|
| `.specify/` | Constitutional and specification-driven governance |
| `.claude/agents/` | Executable agent capability contracts |
| `governance/` | Owner decisions, policy, registries and human reports |
| `knowledge/` | Authority and retrieval routing for agents |
| `library/` | Local, source-provenanced advisory knowledge |
| `platform/` | Native Bash/SSH deployment material and service configuration |
| `servers/` | As-built facts and approved targets by host |
| `specs/` | Mission specifications, plans, tasks and acceptance contracts |
| `evidence/` | Generated proof retained after execution |
| `tests/` | Deterministic repository and runtime gates |

## Current truth state

- Repository baseline: **COMPLETE AND LOCALLY VALIDATED**
- Remote repository: **NOT CONFIGURED**
- HXS-1 runtime: **NOT EXECUTED FROM THIS REPOSITORY**
- Claude Code provider routing: **OWNER-APPROVED; NOT CONFIGURED OR ACCEPTED**
- Active mission: `specs/001-hxs1-qwen38-ollama-mvp1/`
- Active agents: Meta-Agent, Owen, Craig, Quincy and Tessa

## Validate

```bash
bash tests/repository/validate.sh
```

## Critical-path rule

For every proposed task, ask: **Does the first message fail to send without this?**

- Yes: MVP-1.
- No: backlog.

There is no third classification.
