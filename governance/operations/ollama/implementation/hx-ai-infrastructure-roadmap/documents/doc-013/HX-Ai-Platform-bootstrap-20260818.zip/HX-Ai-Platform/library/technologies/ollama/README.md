# Ollama knowledge

Craig uses the locked local Ollama source as implementation authority for MVP-1. The source is materialized under ignored `sources/` by `hx-library.sh`.

MVP-1 uses Ollama `v0.32.14`, loopback-only service access and `/srv/hx-ai/ollama/models`.

