# Kimi knowledge

Kimi K3 is the owner-approved default external execution provider for HX Claude Code, pending configuration acceptance. It runs the Meta-Agent and the active Owen → Craig → Quincy implementation chain.

## Selected baseline

| Concern | Value |
|---|---|
| Anthropic-compatible endpoint | `https://api.moonshot.ai/anthropic` |
| Model | `kimi-k3[1m]` |
| Context | 1M tokens |
| Thinking | always on |
| Reasoning effort | `max` |
| Native subagents | `kimi-k3[1m]` |
| HX auto-compact trigger | `1000000` |

The upstream Claude Code guide proposes `1048576` for auto-compaction, but current Claude Code accepts a maximum of `1000000`. HX uses the client-supported value.

Kimi currently documents WebFetch as unavailable and says K3 web search is being updated and is not recommended for near-term production workflows. Neither is an HX configuration acceptance gate.

Kimi does not perform Tessa's final independent-validation stage. The implementation process writes a retained handoff for Tessa's separate DeepSeek V4 Pro process.
