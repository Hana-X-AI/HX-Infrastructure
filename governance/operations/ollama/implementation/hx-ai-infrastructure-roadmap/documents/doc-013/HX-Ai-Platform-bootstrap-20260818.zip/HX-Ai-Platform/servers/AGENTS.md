# Server record contract

- `discovery.md` is immutable as-found evidence plus clearly labelled later validation.
- `target.md` records the approved intended state.
- Runtime evidence belongs under `evidence/` and must never be rewritten into discovery.
- Storage mutations require exact serial resolution and root-device exclusion.
- A host record cannot assign its own role; workload authority lives in governance registries.

