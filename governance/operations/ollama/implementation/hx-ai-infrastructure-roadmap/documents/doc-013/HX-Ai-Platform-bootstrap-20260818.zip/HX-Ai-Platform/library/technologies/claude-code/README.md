# Claude Code knowledge

The Meta-Agent uses this library for Claude Code configuration precedence, model selection, provider endpoints, subagent inheritance, context compaction and verification.

## HX decisions

- The vendor `claude` executable remains unchanged.
- `hx-claude` is the future HX entry point and defaults to the isolated Kimi profile.
- Tessa is launched in a new explicit DeepSeek profile and inherits `deepseek-v4-pro[1m]` from that process.
- Cross-provider work moves through retained evidence, not native subagent routing.
- Provider variables stay out of repository and user `settings.json` files.
- Native subagents remain inside the provider boundary of their Claude Code process.

## Current constraints

- `settings.json` `env` values override shell environment values.
- `CLAUDE_CODE_SUBAGENT_MODEL` overrides subagent frontmatter and per-invocation model selection.
- `CLAUDE_CODE_AUTO_COMPACT_WINDOW` accepts `100000` through `1000000`.
- A non-Anthropic `ANTHROPIC_BASE_URL` disables Remote Control and MCP tool search by default.

See ADR-0004 before implementation.
