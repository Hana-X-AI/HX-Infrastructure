# Claude Code provider operations

This directory holds approved, execution-ready control material for configuring external Claude Code model providers on `hxs-cp`.

The approved operating split is Kimi K3 for Meta-Agent and implementation execution, DeepSeek V4 Pro for Tessa's separate independent-validation process, and DeepSeek V4 Flash for explicitly approved bounded-volume workloads. Configuration remains pending acceptance.

```mermaid
flowchart LR
    R["Recon + ADR"] --> P["Implementation prompt"]
    P --> E["Owner-authorized execution"]
    E --> V["Independent acceptance"]
```

- Architecture authority: `governance/decisions/0004-claude-code-provider-isolation.md`
- Provider registry: `governance/registries/claude-code-provider-routing.md`
- Execution handoff: `implementation-prompt.md`

No configuration has been executed from this package.
