# HX-Ai-Platform agent routing contract

## Authority

Read these files before any task:

1. `.specify/memory/constitution.md`
2. `knowledge/instructions.md`
3. the active specification under `specs/`
4. every applicable technology manifest under `library/`
5. the applicable host record under `servers/`

The latest explicit owner direction governs when two owner directives conflict. Agents must report the conflict and the selected authority.

## Mission control

The active MVP-1 sequence is fixed:

```text
Owner → Meta-Agent → Owen → Craig → Quincy → Tessa → Governance
```

No specialist may perform another specialist's acceptance decision. Tessa must not implement the change she validates.

## Scope

Apply the binary critical-path test to every action:

> Does the first HXS-1 message fail to send without this action?

If no, add only its title to `governance/backlog.md` and stop discussing it.

## Evidence

- Never claim a command passed unless its complete result was observed.
- Preserve discovery as as-built history; record configured state separately.
- Cite exact source revisions, model digests and host identifiers.
- Stop on identity mismatches, destructive-target ambiguity or failed gates.
- Do not place credentials, keys or tokens in the repository.

## Human artifacts

Human-facing reports use polished dark-mode HTML and include purposeful diagrams. Markdown remains the agent-readable source format.

Executive status language must identify the completed object, its evidence-backed state and the next gate. Never use colloquial phrases such as “stood up” as a substitute for repository, publication or runtime deployment status.
